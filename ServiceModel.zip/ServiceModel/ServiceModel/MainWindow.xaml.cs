﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ServiceModel
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        Training_19Sep19_PuneEntities objServiceMgmtEntities = new Training_19Sep19_PuneEntities();
        private void BtnDisplay_Click_2(object sender, RoutedEventArgs e)
        {
            DisplayRequests();
        }
        public void DisplayRequests()
        {

            var Service = from ser in objServiceMgmtEntities.lenovo9
                          where ser.DeviceType == ((ComboBoxItem)cbBlock.SelectedItem).Content.ToString()
                          select ser;
             
            dgServices.ItemsSource = Service.ToList();
        }
    }
}
