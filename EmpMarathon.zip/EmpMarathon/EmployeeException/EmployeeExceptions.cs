﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeException
{
    public class EmployeeExceptions :ApplicationException 
    {
        public EmployeeExceptions() : base() { }
        public EmployeeExceptions(string msg) : base(msg) { }
        public EmployeeExceptions(string msg, Exception innerexception) : base(msg, innerexception)
        { }
    }
}
