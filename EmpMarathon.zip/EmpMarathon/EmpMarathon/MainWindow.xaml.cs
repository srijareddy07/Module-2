﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using EmpBAL;
using EmployeeEntities;
using EmployeeException;

namespace EmpMarathon
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnRegister_Click(object sender, RoutedEventArgs e)
        {
            Employee newEmp = new Employee();
            try
            {
                newEmp.EmpId = txtId.Text;
                newEmp.EmpName = txtName.Text;
                if (rd_Male.IsChecked == true)
                {
                    newEmp.Gender = "Male";
                }
                else
                {
                    newEmp.Gender = "Female";
                }
                newEmp.Location = txtLocation.Text;
                newEmp.Contact = txtContact.Text;
                newEmp.BloodGroup = txtBloodGrp.Text;
                newEmp.Coverage = txtCoverage.Text;

                int custInserted = EmployeeBAL.AddEmployeeBL(newEmp);

                if (custInserted > 0)
                {
                    MessageBox.Show("Thank you! Details successfully registered");
                    Clear();
                    //Display();
                }
                else
                    throw new EmployeeExceptions("Customer record not inserted");
            }
            catch (EmployeeExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void BtnReset_Click(object sender, RoutedEventArgs e)
        {
            Clear();
        }
        public void Clear()
        {
            txtId.Text = "";
            txtName.Text = "";


            txtLocation.Text = "";
            txtContact.Text = "";
            txtBloodGrp.Text = "";
            txtCoverage.Text = "";
        }

        private void Rd_Male_Checked(object sender, RoutedEventArgs e)
        {

        }
    }
}
