﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using EmpDAL;
using EmployeeEntities;
using EmployeeException;

namespace EmpBAL
{
    public class EmployeeBAL
    {
        public static bool ValidateEmployee(Employee newEmp)
        {
            StringBuilder message = new StringBuilder();
            bool validEmployee = true;

            try
            {
                if (newEmp.EmpId == string.Empty)
                {
                    message.Append("Employee Id should be provided\n");
                    validEmployee = false;
                }
                else if (!Regex.IsMatch(newEmp.EmpId, "[0-9]{6}"))
                {
                    message.Append("Employee Id should contain 6 digits exactly\n");
                    validEmployee = false;
                }
                if (newEmp.EmpName == string.Empty)
                {
                    message.Append("Employee name should be provided\n");
                    validEmployee = false;
                }
                else if (!Regex.IsMatch(newEmp.EmpName, "^[A-Z][a-z]+"))
                {
                    message.Append("Employee name should start with Capital letter and it should have alphabets only\n");
                    validEmployee = false;
                }


                if (newEmp.Gender == string.Empty)
                {
                    message.Append("Gender should be provided\n");
                    validEmployee = false;
                }




                if (newEmp.Contact == String.Empty)
                {
                    message.Append("Contact number should be provided\n");
                    validEmployee = false;
                }
                else if (!Regex.IsMatch(newEmp.Contact, "[7-9][0-9]{9}"))
                {
                    message.Append("Contact number should start with 7 or 8 or 9 and it should have exactly 10 digits\n");
                    validEmployee = false;
                }

                if (validEmployee == false)
                {
                    throw new EmployeeExceptions(message.ToString());
                }
            }
            catch (EmployeeExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return validEmployee;
        }
        public static int AddEmployeeBL(Employee employee)
        {
            int employeeAdded = 0;
            try
            {
                if (ValidateEmployee(employee))
                {
                    EmployeeDAL employeeDAL = new EmployeeDAL();
                    employeeAdded = EmployeeDAL.RegisterEmployee(employee);
                    return employeeAdded;
                }
            }
            catch (EmployeeExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return employeeAdded;
        }
    }
}
