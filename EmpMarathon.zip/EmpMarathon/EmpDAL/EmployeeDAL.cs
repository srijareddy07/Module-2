﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeEntities;
using EmployeeException;

namespace EmpDAL
{
    public class EmployeeDAL
    {

        public static int RegisterEmployee(Employee objEmployee)
        {
            int employeeAdded = 0;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HRDSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008575].Survey", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_EmpId = new SqlParameter("@EmpId", objEmployee.EmpId);
                SqlParameter objSqlParam_EmpName = new SqlParameter("@EmpName", objEmployee.EmpName);
                SqlParameter objSqlParam_Gender = new SqlParameter("@Gender", objEmployee.Gender);
                SqlParameter objSqlParam_Location = new SqlParameter("@Location", objEmployee.Location);
                SqlParameter objSqlParam_Contact = new SqlParameter("@Contact", objEmployee.Contact);
                SqlParameter objSqlParam_BloodGroup = new SqlParameter("BloodGroup", objEmployee.BloodGroup);
                SqlParameter objSqlParam_Coverage = new SqlParameter("@Coverage", objEmployee.Coverage);
             
              


                objCom.Parameters.Add(objSqlParam_EmpId);
                objCom.Parameters.Add(objSqlParam_EmpName);
                objCom.Parameters.Add(objSqlParam_Gender);
                objCom.Parameters.Add(objSqlParam_Location);
                objCom.Parameters.Add(objSqlParam_Contact);
                objCom.Parameters.Add(objSqlParam_BloodGroup);
                objCom.Parameters.Add(objSqlParam_Coverage);
                
               

                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                employeeAdded = 1;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return employeeAdded;
        }
    }
}
