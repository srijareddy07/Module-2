﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeEntities
{
    public class Employee
    {
        public String EmpId { get; set; }
        public String EmpName { get; set; }
        public String Gender { get; set; }
        public String Location{ get; set; }
        public String Contact { get; set; }
        public String BloodGroup { get; set; }
        public String Coverage { get; set; }
    }
}
