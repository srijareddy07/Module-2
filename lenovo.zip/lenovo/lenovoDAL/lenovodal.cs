﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using lenovoEntities;
using lenovoExceptions;


namespace lenovoDAL
{
    public class lenovodal
    {
        public bool Addlenovodal(lenovo1 objlenovo)
        {
            bool serviceAdded = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["lenovoConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008575].lenovo", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_ServiceId = new SqlParameter("@ServiceId", objlenovo.ServiceId);
                SqlParameter objSqlParam_OwnerName = new SqlParameter("@OwnerName", objlenovo.OwnerName);
                SqlParameter objSqlParam_Date = new SqlParameter("@Date", objlenovo.Date);
                SqlParameter objSqlParam_contact = new SqlParameter("@contact", objlenovo.contact);
                SqlParameter objSqlParam_SerialNumber = new SqlParameter("@SerialNumber", objlenovo.SerialNumber);

                SqlParameter objSqlParam_DeviceType = new SqlParameter("@DeviceType", objlenovo.DeviceType);
                SqlParameter objSqlParam_IssueDescription = new SqlParameter("@IssueDescription", objlenovo.IssueDescription);
                //
                objCom.Parameters.Add(objSqlParam_ServiceId);
                objCom.Parameters.Add(objSqlParam_OwnerName);
                objCom.Parameters.Add(objSqlParam_Date);
                objCom.Parameters.Add(objSqlParam_contact);
                objCom.Parameters.Add(objSqlParam_DeviceType);
                objCom.Parameters.Add(objSqlParam_DeviceType);
               
              

                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                serviceAdded = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new lenovoexception(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return serviceAdded;
        }
    }
}
