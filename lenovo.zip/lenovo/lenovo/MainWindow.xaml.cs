﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using lenovoBAL;
using lenovoEntities;
using lenovoExceptions;
namespace lenovo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnSubmitRequest_Click(object sender, RoutedEventArgs e)
        {

        


       
            Addservice();

        }
        private void Addservice()
        {
            try
            {
                int id;
                string name;
                int contactnumber;
                DateTime date;
               

                int serialnumber;
             
                //
                bool serviceAdded;
                //
                id = Convert.ToInt32(txtserviceid.Text);
                name = txtOwnerName.Text;
                contactnumber = Convert.ToInt32(txtcontactno.Text);
                date = Convert.ToDateTime(txtDate.Text);
               
              

               
                serialnumber= Convert.ToInt32(txtserialNo.Text);


                lenovo1 objlenovo = new lenovo1()

                {
                    ServiceId = id,
                    OwnerName = name,
                    Date = date,
                    contact = contactnumber,
                   
                    SerialNumber = serialnumber,
                   
          
         



                };
                serviceAdded = lenovobal.AddlenovoBAL(objlenovo);
                if (serviceAdded == true)
                {
                    MessageBox.Show("service request submitted  successfully.");
                }
                else
                {
                    MessageBox.Show("service request  couldn't be added.");
                }
            }
            catch (lenovoexception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Lbdevicetype_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
