﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using lenovoDAL;
using lenovoEntities;
using lenovoExceptions;

namespace lenovoBAL
{
    public class lenovobal
    {
        private static bool Validatelenovo(lenovo1 lenovo)
        {
            StringBuilder sb = new StringBuilder();
            bool validservice = true;
            if (lenovo.ServiceId <= 0)
            {
                validservice = false;
                sb.Append(Environment.NewLine
                    + "service Id should be of 6 characters");
            }
            if (lenovo.OwnerName == string.Empty)
            {
                validservice = false;
                
                sb.Append(Environment.NewLine + "owner Name can't be empty.");
            }
            if (Convert.ToString(lenovo.DeviceType).Length < 1)
            {
                validservice = false;
                sb.Append(Environment.NewLine + "device type must have laptop,mobile or desktop");
            }
            if (Convert.ToString(lenovo.Date).Length < 1)
            {
                validservice = false;
                sb.Append(Environment.NewLine + "date should be less than current date");
            }
             if (Convert.ToString(lenovo.contact).Length < 1)
                {
                    validservice = false;
                    sb.Append(Environment.NewLine + "contact number must be of 10 digits");
                }
            if (Convert.ToString(lenovo.SerialNumber).Length < 1)
            {
                validservice = false;
                sb.Append(Environment.NewLine + "serial number must have format");
            }

            if (validservice == false)
            {
                throw new lenovoexception(sb.ToString());
            }
            return validservice;

        }

        public static bool Addlenovodal(lenovo1 lenovo)
        {
            bool serviceAdded = false;
            try
            {
                if (Validatelenovo(lenovo))
                {
                   lenovodal lenovoDAL = new lenovodal();
                    serviceAdded = lenovoDAL.Addlenovodal(lenovo);
                    return serviceAdded;
                }
            }
            catch (lenovoexception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return serviceAdded;
        }

        public static bool AddlenovoBAL(lenovo1 objlenovo)
        {
            throw new NotImplementedException();
        }
    }
}
