﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lenovoEntities
{
    public class lenovo1
    {
        public int ServiceId { get; set; }
        public DateTime Date { get; set; }
        public string OwnerName { get; set; }
        public int contact { get; set; }
        public string DeviceType { get; set; }

        public int SerialNumber { get; set; }
        public string IssueDescription { get; set; }
        public DateTime RequestDate { get; set; }

        public lenovo1()
        {

        }


    }
}
